#!/usr/bin/env python
# coding: utf-8

# In[1]:


from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    
    def __init__(self):
        USER = 'aacuser'
        PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32011
        DB = 'AAC'
        COL = 'animals'
        
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

    def create(self, data):
        if data is not None:
            try:
                self.database.animals.insert_one(data)
                return True
            except Exception as e:
                print(f"Error during insertion: {e}")
                return False
            
        else:
            raise Exception("Nothing to save, because data parameter is empty")
    
    def read(self, query):
        if query is not None:
            try:
                result = self.collection.find(query)
                return list(result)
            except Exception as e:
                print(f"Error during read: {e}")
                return[]
        else:
            raise Exception("Query parameter cannot be None")
            
    def update(self, query, data):
        if data and query is not None:
            try:
                result = self.collection.update_one(query, {'$set': data})
                return result.modified_count
            except Exception as e:
                print(f"Error during update: {e}")
                return 0
        else:
            raise Exception("Nothing to update with empty data parameter")
            
    def delete(self, query):
        if query is not None:
            try:
                result = self.collection.delete_one(query)
                return result.deleted_count
            except Exception as e:
                print(f"Error during deletion: {e}")
                return 0
        else:
            raise Exception("Nothing to delete with empty query parameter")
            


# In[ ]:





# In[ ]:




