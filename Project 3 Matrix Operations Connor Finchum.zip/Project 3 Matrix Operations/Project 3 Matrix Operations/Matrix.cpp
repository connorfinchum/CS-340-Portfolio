
#include <iostream>
#include "Matrix.h"
using namespace std;

Matrix::Matrix() {

}

//populates matrices with numbers
void Matrix::pop(int num)
{
	for (int i = 0; i < 99; i++) {
		for (int j = 0; j < 99; j++) {
			m[i][j] = num;
		}
	}

}

//operator for matrix addition
Matrix& Matrix::operator + (int add) {
	Matrix temp;
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			temp.m[i][j] = m[i][j] + add;
		}
	}
	return temp;
}

//operator for matrix subtraction
Matrix& Matrix::operator - (int add) {
	Matrix temp;
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			temp.m[i][j] = m[i][j] - add;
		}
	}
	return temp;
}

//operator for matrix multiplication
Matrix& Matrix::operator * (int add) {
	Matrix temp;
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			temp.m[i][j] = m[i][j] * add;
		}
	}
	return temp;
}

//print matrix
void Matrix::print() {
	cout << "Matrix " << row << "x" << col << endl;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			cout << m[i][j] << " ";
		}
		cout << endl;
	}
}

//operator for matrix addition
Matrix& Matrix::operator + (Matrix& m2)
{
	Matrix temp;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			temp.m[i][j] = m[i][j] + m2.m[i][j];
		}
	}
	return temp;
}

//operator for matrix subtraction
Matrix& Matrix::operator - (Matrix& m2)
{
	Matrix temp;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			temp.m[i][j] = m[i][j] - m2.m[i][j];
		}
	}
	return temp;
}

//operator for matrix multiplication
Matrix& Matrix::operator * (Matrix& m2)
{
	Matrix temp;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			temp.m[i][j] = m[i][j] * m2.m[i][j];
		}
	}
	return temp;
}

