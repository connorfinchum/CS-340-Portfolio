#include <iostream>
using namespace std;
#include "Matrix.h"

ostream& operator << (ostream& os, Matrix& m2)
{
	os << "operator Matrix " << m2.row << " by " << m2.col << endl;
	for (int i = 0; i < m2.row; i++)
	{
		for (int j = 0; j < m2.col; j++)
		{
			os << m2.m[i][j] << " ";
		}
		os << endl;
	}
	return (os);
}

int main() {
	int numset;
	int numset2;
	int numset3;
	int num2set;
	int a;
	int m2n;
	Matrix m;
	Matrix m2;
	cout << "Enter how many rows you want: " << endl;
	cin >> numset;
	cout << "Enter how many columns: " << endl;
	cin >> num2set;
	m.setRC(numset, num2set);
	cout << "Enter how many rows for matrix 2: " << endl;
	cin >> numset2;
	cout << "Enter how many columns for matrix 2: " << endl;
	cin >> numset3;
	while (numset != numset2 || num2set != numset3) {
		try
		{
			if (numset != numset2) {
				throw numset2;

			}
			else if (num2set != numset3) {
				throw numset3;
			}
		}
		catch (int w)
		{
			cout << "Try again: \n";
		}
		cout << "Enter how many rows you want for matrix 2 " << endl;
		cin >> numset2;
		cout << "Enter how many columns for matrix 2 " << endl;
		cin >> numset3;
	}
	//operations of matrices including population
	m2.setRC(numset2, numset3);
	cout << "Enter the number which you wish to populate matrix 1 with " << endl;
	cin >> a;
	m.pop(a);
	m.print();
	cout << "Enter the number you wish to populate matrix 2 with " << endl;
	cin >> m2n;
	m2.pop(m2n);
	m2.print();
	m = m + m2;
	m.setRC(numset, num2set);
	cout << "Addition " << endl;
	m.print();
	m.pop(a);
	m = m - m2;
	m.setRC(numset, num2set);
	cout << "Subtraction " << endl;
	m.print();
	m.pop(a);
	m = m * m2;
	m.setRC(numset, num2set);
	cout << "Multiplication " << endl;
	m.print();
	return 0;
}
