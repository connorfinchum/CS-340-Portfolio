#pragma once

#include <iostream>
using namespace std;
class Matrix {

public:
	int row = 100;
	int col = 100;
	void setRC(int a, int b) {
		row = a;
		col = b;
	}
	Matrix();
	void pop(int num);
	int size;
	int m[100][100];
	void print();
	//operator overlaods
	Matrix& operator + (int add);
	Matrix& operator + (Matrix& m);
	Matrix& operator - (int add);
	Matrix& operator - (Matrix& m);
	Matrix& operator * (int add);
	Matrix& operator * (Matrix& m);
};